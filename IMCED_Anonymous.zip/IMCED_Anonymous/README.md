# IM-CED Anonymous Replication Artifact

This repository contains the replication material for the anonymous submission:

**IM-CED: Learning from Symbolically Verified Counterexamples for Vulnerability Detection**

## Dataset

The final experiment uses 98 memory-safety tasks from SV-COMP.

Fixed stratified partition:

- Training: 58 programs (29 vulnerable, 29 safe)
- Feedback: 20 programs (10 vulnerable, 10 safe)
- Untouched test: 20 programs (10 vulnerable, 10 safe)

Ground-truth labels are obtained from the relevant SV-COMP memory-safety properties.

## Method

The experiment uses:

- frozen `microsoft/codebert-base` representations;
- a trainable logistic classification head;
- class-balanced training;
- uncertainty-based candidate selection;
- KLEE symbolic execution;
- verified counterexample criterion: `.err` + matching `.ktest`;
- 2 counterexample-feedback rounds;
- top-10 uncertain candidates per round;
- five seeds: 42, 123, 456, 789, 999.

## Repository Structure

- `scripts/` - final experiment implementation
- `data/` - fixed train/feedback/test split
- `results/` - final reported experimental results
- `witnesses/` - representative KLEE `.err` and `.ktest` witnesses
- `configs/` - experimental configuration

## Installation

Install the required Python packages using:

```bash
python3 -m pip install -r requirements.txt
Running the Experiment
Set the experiment root containing the SV-COMP benchmark repository and KLEE outputs:
IMCED_BASE=/path/to/experiment python3 scripts/run_multi_seed_eval.py
Experimental Configuration
The main experimental configuration is:
- CodeBERT model: microsoft/codebert-base
- CodeBERT parameters: frozen
- Classification head: logistic classifier
- Class weighting: balanced
- Decision threshold: 0.50
- Counterexample-feedback rounds: 2
- Verification budget: 10 candidates per round
- Random seeds: 42, 123, 456, 789, 999
A program is considered a verified counterexample only when KLEE produces both an .err file and the corresponding .ktest file.
The absence of a KLEE witness is treated as inconclusive and is not interpreted as evidence that a program is safe.
Final Results
Configuration	Accuracy (%)	Precision (%)	Recall (%)	F1-Score (%)
CodeBERT Semantic Head	68.00 ± 6.00	70.76 ± 9.55	64.00 ± 4.90	66.82 ± 4.92
Static Pattern Only	60.00	66.67	40.00	50.00
KLEE Symbolic Execution Only	75.00	100.00	50.00	66.67
IM-CED (Hybrid, No Retraining)	80.00	100.00	60.00	75.00
IM-CED (Proposed CE Feedback)	76.00 ± 7.35	77.10 ± 6.94	74.00 ± 10.20	75.31 ± 8.03


Across five runs, the proposed counterexample-guided configuration improves the mean F1-score from 66.82% for the CodeBERT semantic baseline to 75.31%.
The paired t-test gives p = 0.1516, while the Wilcoxon signed-rank test gives p = 0.1250. Therefore, the observed improvement is not claimed to be statistically significant.
Verified Counterexample Evidence
Representative KLEE-generated witnesses are provided under the witnesses/ directory.
Included examples are:
- add_last_unsafe
  - test000002.ptr.err
  - test000002.ktest
- reverse_array_unsafe
  - test000002.ptr.err
  - test000002.ktest
These artifacts provide executable evidence of the failure paths identified by KLEE.
Reproducibility Files
The repository includes:
- the final experiment script;
- the exact fixed train/feedback/test partition;
- the final experimental results;
- the experiment configuration;
- representative KLEE counterexample witnesses.