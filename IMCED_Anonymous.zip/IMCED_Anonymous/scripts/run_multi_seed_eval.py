import os
import re
import glob
import json
import warnings
from collections import defaultdict

import yaml
import numpy as np
import torch
import torch.nn.functional as F
from transformers import AutoTokenizer, AutoModel
from sklearn.linear_model import SGDClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import StratifiedShuffleSplit
from sklearn.metrics import accuracy_score, precision_recall_fscore_support
from scipy import stats

warnings.filterwarnings("ignore")


# ============================================================
# CONFIGURATION
# ============================================================

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
WINDOWS_BASE = os.environ.get(
    "IMCED_BASE",
    os.getcwd()
)
BENCH_ROOT = os.path.join(WINDOWS_BASE, "sv-benchmarks", "c")
KLEE_RUNS_DIR = os.path.join(WINDOWS_BASE, "klee_svcomp_output")

SEEDS = [42, 123, 456, 789, 999]

CE_ROUNDS = 2
CE_BUDGET = 10
SEMANTIC_THRESHOLD = 0.50

TARGET_DIRS = [
    "array-memsafety",
    "memsafety",
    "memsafety-ext",
    "list-ext-properties",
]

MEMORY_SAFETY_PROPERTIES = {
    "valid-memsafety.prp",
    "valid-deref.prp",
    "valid-free.prp",
    "valid-memtrack.prp",
    "valid-memcleanup.prp",
}


# ============================================================
# 1. CORRECT SV-COMP MEMORY-SAFETY LABELS
# ============================================================

def parse_memory_safety_verdict(c_file_path):
    """
    1 = memory-safety violation
    0 = memory-safe
    None = no relevant memory-safety property
    """

    yml_path = c_file_path[:-2] + ".yml"

    if not os.path.exists(yml_path):
        return None

    try:
        with open(yml_path, "r", errors="ignore") as f:
            task = yaml.safe_load(f)
    except Exception:
        return None

    if not isinstance(task, dict):
        return None

    relevant_verdicts = []

    for prop in task.get("properties", []):

        if not isinstance(prop, dict):
            continue

        property_file = str(
            prop.get("property_file", "")
        )

        property_name = os.path.basename(
            property_file
        )

        if property_name not in MEMORY_SAFETY_PROPERTIES:
            continue

        verdict = prop.get(
            "expected_verdict",
            None
        )

        if verdict is True:
            relevant_verdicts.append(True)

        elif verdict is False:
            relevant_verdicts.append(False)

    if len(relevant_verdicts) == 0:
        return None

    # If ANY relevant memory-safety property is violated,
    # classify the program as vulnerable.
    if any(v is False for v in relevant_verdicts):
        return 1

    if all(v is True for v in relevant_verdicts):
        return 0

    return None


# ============================================================
# 2. LOAD BALANCED SV-COMP MEMORY-SAFETY DATA
# ============================================================

vuln_pool = []
safe_pool = []
ignored_no_property = 0


for target_dir in TARGET_DIRS:

    directory = os.path.join(
        BENCH_ROOT,
        target_dir
    )

    if not os.path.exists(directory):
        continue

    for c_path in sorted(
        glob.glob(
            os.path.join(
                directory,
                "*.c"
            )
        )
    ):

        label = parse_memory_safety_verdict(
            c_path
        )

        if label == 1:
            vuln_pool.append(c_path)

        elif label == 0:
            safe_pool.append(c_path)

        else:
            ignored_no_property += 1


target_per_class = min(
    len(vuln_pool),
    len(safe_pool),
    120
)


if target_per_class == 0:

    raise RuntimeError(
        "No usable memory-safety SV-COMP tasks found."
    )


selected_paths = (
    vuln_pool[:target_per_class]
    +
    safe_pool[:target_per_class]
)


# ============================================================
# DUPLICATE FILENAME CHECK
# ============================================================

seen = defaultdict(list)


for path in selected_paths:

    seen[
        os.path.basename(path)
    ].append(path)


duplicates = {

    name: paths

    for name, paths in seen.items()

    if len(paths) > 1

}


if duplicates:

    raise RuntimeError(
        "Duplicate basenames found. "
        "KLEE mapping must be path-aware before continuing."
    )


# ============================================================
# 3. SOURCE PREPROCESSING
# ============================================================

def sanitize_for_codebert(code):

    # Remove comments
    code = re.sub(
        r"/\*[\s\S]*?\*/|//.*",
        "",
        code
    )

    # Normalize benchmark-specific error calls
    code = re.sub(
        r"__VERIFIER_error\s*\(\s*\)|"
        r"reach_error\s*\(\s*\)|"
        r"assert_fail",
        "__verification_sink",
        code
    )

    code = re.sub(
        r"\n\s*\n",
        "\n",
        code
    )

    return code.strip()


# ============================================================
# LIGHTWEIGHT STATIC EVIDENCE
# ============================================================

def static_pattern_signal(raw_code):

    risky_operations = [

        "malloc",
        "calloc",
        "realloc",
        "free",
        "strcpy",
        "strncpy",
        "strcat",
        "memcpy",
        "memmove",
        "->next",
        "->prev",

    ]


    guard_operations = [

        "__VERIFIER_assert",
        "assert(",
        "reach_error(",
        "exit(0)",

    ]


    has_risky_operation = any(

        op in raw_code

        for op in risky_operations

    )


    has_guard = any(

        guard in raw_code

        for guard in guard_operations

    )


    return (

        1

        if (
            has_risky_operation
            and
            not has_guard
        )

        else 0

    )


# ============================================================
# 4. BUILD DATASET
# ============================================================

dataset = []


for c_path in selected_paths:

    label = parse_memory_safety_verdict(
        c_path
    )


    if label is None:
        continue


    with open(
        c_path,
        "r",
        errors="ignore"
    ) as f:

        raw_source = f.read()


    dataset.append({

        "file":
            os.path.basename(
                c_path
            ),

        "path":
            c_path,

        "code":
            sanitize_for_codebert(
                raw_source
            ),

        "label":
            label,

        "static":
            static_pattern_signal(
                raw_source
            )

    })


# ============================================================
# 5. REAL KLEE WITNESS CHECK
#
# IMPORTANT:
# Ground-truth label is NEVER consulted here.
# ============================================================

klee_cache = {}


def has_klee_witness(dataset_index):

    idx = int(
        dataset_index
    )


    if idx in klee_cache:

        return klee_cache[
            idx
        ]


    c_path = dataset[
        idx
    ]["path"]


    basename = os.path.splitext(

        os.path.basename(
            c_path
        )

    )[0]


    run_dir = os.path.join(

        KLEE_RUNS_DIR,

        f"run_{basename}"

    )


    witness_found = 0


    for err_file in glob.glob(

        os.path.join(
            run_dir,
            "*.err"
        )

    ):


        if err_file.endswith(
            ".model.err"
        ):
            continue


        # Example:
        #
        # test000001.ptr.err
        #
        # becomes:
        #
        # test000001.ktest

        prefix = err_file.rsplit(
            ".",
            2
        )[0]


        ktest_file = (
            prefix
            +
            ".ktest"
        )


        if os.path.exists(
            ktest_file
        ):

            witness_found = 1

            break


    klee_cache[
        idx
    ] = witness_found


    return witness_found


# ============================================================
# 6. LOAD FROZEN CODEBERT
# ============================================================

tokenizer = AutoTokenizer.from_pretrained(
    "microsoft/codebert-base"
)


codebert = AutoModel.from_pretrained(
    "microsoft/codebert-base"
).to(
    DEVICE
).eval()


def embed_code(code_string):

    encoded = tokenizer(

        code_string,

        return_tensors="pt",

        max_length=256,

        truncation=True,

        padding=True

    ).to(
        DEVICE
    )


    with torch.no_grad():

        output = codebert(
            **encoded
        )


    mask = (

        encoded[
            "attention_mask"
        ]

        .unsqueeze(
            -1
        )

        .expand(
            output.last_hidden_state.size()
        )

        .float()

    )


    pooled = (

        torch.sum(

            output.last_hidden_state
            *
            mask,

            dim=1

        )

        /

        torch.clamp(

            mask.sum(
                dim=1
            ),

            min=1e-9

        )

    )


    pooled = F.normalize(

        pooled,

        p=2,

        dim=1

    )


    return (

        pooled

        .squeeze(
            0
        )

        .cpu()

        .numpy()

    )


print(

    f"\n[1/4] Extracting CodeBERT representations for "
    f"{len(dataset)} memory-safety SV-COMP tasks..."

)


all_embeddings = np.asarray(

    [

        embed_code(
            item["code"]
        )

        for item in dataset

    ],

    dtype=np.float32

)


all_labels = np.asarray(

    [

        item["label"]

        for item in dataset

    ],

    dtype=np.int64

)


all_static = np.asarray(

    [

        item["static"]

        for item in dataset

    ],

    dtype=np.int64

)


# ============================================================
# 7. FIXED STRATIFIED 60 / 20 / 20 SPLIT
# ============================================================

indices = np.arange(
    len(dataset)
)


split_test = StratifiedShuffleSplit(

    n_splits=1,

    test_size=0.20,

    random_state=42

)


train_feedback_indices, test_indices = next(

    split_test.split(

        indices,

        all_labels

    )

)


split_feedback = StratifiedShuffleSplit(

    n_splits=1,

    test_size=0.25,

    random_state=42

)


relative_train, relative_feedback = next(

    split_feedback.split(

        train_feedback_indices,

        all_labels[
            train_feedback_indices
        ]

    )

)


train_indices = train_feedback_indices[
    relative_train
]


feedback_indices = train_feedback_indices[
    relative_feedback
]


# ============================================================
# VERIFY NO DATA LEAKAGE
# ============================================================

assert set(
    train_indices
).isdisjoint(
    feedback_indices
)


assert set(
    train_indices
).isdisjoint(
    test_indices
)


assert set(
    feedback_indices
).isdisjoint(
    test_indices
)


print(
    "\n[Fixed Dataset Partition Established]"
)


print(

    f"  - Total Evaluated Tasks: "
    f"{len(dataset)}"

)


print(

    f"  - Initial Training Set:   "
    f"{len(train_indices)} "
    f"("
    f"{np.sum(all_labels[train_indices] == 1)} Vuln, "
    f"{np.sum(all_labels[train_indices] == 0)} Safe"
    f")"

)


print(

    f"  - Active Feedback Pool:   "
    f"{len(feedback_indices)} "
    f"("
    f"{np.sum(all_labels[feedback_indices] == 1)} Vuln, "
    f"{np.sum(all_labels[feedback_indices] == 0)} Safe"
    f")"

)


print(

    f"  - Untouched Test Set:     "
    f"{len(test_indices)} "
    f"("
    f"{np.sum(all_labels[test_indices] == 1)} Vuln, "
    f"{np.sum(all_labels[test_indices] == 0)} Safe"
    f")"

)


print(

    f"  - Ignored tasks without relevant "
    f"memory-safety property: "
    f"{ignored_no_property}"

)


# ============================================================
# SAVE FIXED SPLIT
# ============================================================

split_information = {


    "train": [

        dataset[i]["file"]

        for i in train_indices

    ],


    "feedback": [

        dataset[i]["file"]

        for i in feedback_indices

    ],


    "test": [

        dataset[i]["file"]

        for i in test_indices

    ]

}


split_file = os.path.join(

    WINDOWS_BASE,

    "imced_fixed_split_memorysafe.json"

)


with open(
    split_file,
    "w"
) as f:

    json.dump(

        split_information,

        f,

        indent=2

    )


# ============================================================
# 8. TRAIN CLASSIFIER
# ============================================================

def train_classifier(
    X_raw,
    y_raw,
    seed
):


    scaler = StandardScaler()


    X_scaled = scaler.fit_transform(

        np.asarray(

            X_raw,

            dtype=np.float32

        )

    )


    y = np.asarray(

        y_raw,

        dtype=np.int64

    )


    classifier = SGDClassifier(

        loss="log_loss",

        penalty="l2",

        alpha=1e-3,

        max_iter=1000,

        random_state=seed,

        shuffle=True,

        class_weight="balanced"

    )


    classifier.fit(

        X_scaled,

        y

    )


    return (
        scaler,
        classifier
    )


# ============================================================
# PREDICT PROBABILITY
# ============================================================

def predict_probability(
    scaler,
    classifier,
    indices_to_predict
):


    transformed = scaler.transform(

        all_embeddings[
            indices_to_predict
        ]

    )


    return classifier.predict_proba(

        transformed

    )[:, 1]


# ============================================================
# UNCERTAINTY
#
# U(x) = 1 - |2p(x) - 1|
# ============================================================

def uncertainty_score(
    probability
):


    return (

        1.0

        -

        np.abs(

            2.0
            *
            probability
            -
            1.0

        )

    )


# ============================================================
# METRICS
# ============================================================

def calculate_metrics(
    y_true,
    y_pred
):


    accuracy = accuracy_score(

        y_true,

        y_pred

    ) * 100


    precision, recall, f1, _ = (

        precision_recall_fscore_support(

            y_true,

            y_pred,

            average="binary",

            zero_division=0

        )

    )


    return {

        "acc":
            accuracy,

        "prec":
            precision * 100,

        "rec":
            recall * 100,

        "f1":
            f1 * 100

    }


# ============================================================
# 9. EXPERIMENTAL METHODS
# ============================================================

methods = [

    "CodeBERT Semantic Head",

    "Static Pattern Only",

    "KLEE Symbolic Exec Only",

    "IM-CED (Hybrid, No Retraining)",

    "IM-CED (Proposed CE Feedback)"

]


metrics = {

    method: {

        "acc": [],

        "prec": [],

        "rec": [],

        "f1": []

    }

    for method in methods

}


feedback_history = {}


y_test = all_labels[
    test_indices
]


static_test = all_static[
    test_indices
]


# ------------------------------------------------------------
# KLEE test evidence is used ONLY for:
#
# 1. KLEE-only baseline
# 2. Hybrid-no-retraining baseline
#
# It is NOT used for proposed model retraining.
# ------------------------------------------------------------

klee_test = np.asarray(

    [

        has_klee_witness(
            i
        )

        for i in test_indices

    ],

    dtype=np.int64

)


# ============================================================
# 10. FIVE-SEED EXPERIMENT
# ============================================================

print(

    f"\n[2/4] Training across "
    f"{len(SEEDS)} seeds..."

)


for seed in SEEDS:


    print(
        "\n---------------------------------------------"
    )


    print(
        f"Seed = {seed}"
    )


    # ========================================================
    # INITIAL TRAINING
    # ========================================================

    rng = np.random.default_rng(
        seed
    )


    permuted_train = rng.permutation(
        train_indices
    )


    training_X = list(

        all_embeddings[
            permuted_train
        ]

    )


    training_y = list(

        all_labels[
            permuted_train
        ]

    )


    base_scaler, base_classifier = train_classifier(

        training_X,

        training_y,

        seed

    )


    # ========================================================
    # CODEBERT BASELINE
    # ========================================================

    semantic_probability = predict_probability(

        base_scaler,

        base_classifier,

        test_indices

    )


    semantic_prediction = (

        semantic_probability
        >=
        SEMANTIC_THRESHOLD

    ).astype(
        int
    )


    # ========================================================
    # HYBRID WITHOUT RETRAINING
    # ========================================================

    hybrid_prediction = np.where(

        klee_test == 1,

        1,

        np.where(

            (
                semantic_probability
                >=
                SEMANTIC_THRESHOLD
            )

            &

            (
                static_test == 1
            ),

            1,

            0

        )

    ).astype(
        int
    )


    # ========================================================
    # COUNTEREXAMPLE-GUIDED REFINEMENT
    # ========================================================

    current_X = list(
        training_X
    )


    current_y = list(
        training_y
    )


    current_scaler = base_scaler


    current_classifier = base_classifier


    checked_feedback = set()


    verified_counterexamples = set()


    seed_history = []


    for round_number in range(

        1,

        CE_ROUNDS + 1

    ):


        # ----------------------------------------------------
        # ONLY UNCHECKED FEEDBACK PROGRAMS
        # ----------------------------------------------------

        available = np.asarray(

            [

                idx

                for idx in feedback_indices

                if int(idx)
                not in checked_feedback

            ],

            dtype=int

        )


        if len(
            available
        ) == 0:

            break


        # ----------------------------------------------------
        # PREDICT FEEDBACK PROBABILITY
        # ----------------------------------------------------

        feedback_probability = predict_probability(

            current_scaler,

            current_classifier,

            available

        )


        # ----------------------------------------------------
        # UNCERTAINTY-BASED SELECTION
        # ----------------------------------------------------

        uncertainty = uncertainty_score(

            feedback_probability

        )


        ranking = np.argsort(

            -uncertainty

        )


        selected = available[

            ranking[

                :min(
                    CE_BUDGET,
                    len(ranking)
                )

            ]

        ]


        verified_this_round = []


        print(

            f"  Feedback Round {round_number}: "
            f"selected {len(selected)} candidates"

        )


        # ----------------------------------------------------
        # SYMBOLIC VERIFICATION
        # ----------------------------------------------------

        for idx in selected:


            idx = int(
                idx
            )


            checked_feedback.add(
                idx
            )


            static_signal = int(

                all_static[
                    idx
                ]

            )


            klee_signal = int(

                has_klee_witness(
                    idx
                )

            )


            print(

                f"    {dataset[idx]['file']} "

                f"| static={static_signal} "

                f"| KLEE_witness={klee_signal}"

            )


            # ------------------------------------------------
            # VERIFIED COUNTEREXAMPLE
            #
            # Only .err + matching .ktest.
            #
            # NO ground-truth feedback label is used here.
            # ------------------------------------------------

            if klee_signal == 1:


                verified_this_round.append(
                    idx
                )


                if (
                    idx
                    not in verified_counterexamples
                ):


                    verified_counterexamples.add(
                        idx
                    )


                    current_X.append(

                        all_embeddings[
                            idx
                        ]

                    )


                    # KLEE concrete witness supplies
                    # the positive CE label.
                    current_y.append(
                        1
                    )


        # ----------------------------------------------------
        # RETRAIN ONLY AFTER NEW VERIFIED CEs
        # ----------------------------------------------------

        if len(
            verified_this_round
        ) > 0:


            current_scaler, current_classifier = train_classifier(

                current_X,

                current_y,

                seed + round_number

            )


        print(

            f"    Verified CEs this round: "
            f"{len(verified_this_round)}"

        )


        print(

            f"    Cumulative verified CEs: "
            f"{len(verified_counterexamples)}"

        )


        seed_history.append({

            "round":
                round_number,

            "selected": [

                dataset[i]["file"]

                for i in selected

            ],

            "verified_counterexamples": [

                dataset[i]["file"]

                for i in verified_this_round

            ],

            "cumulative_verified":
                len(
                    verified_counterexamples
                )

        })


    feedback_history[
        str(seed)
    ] = seed_history


    # ========================================================
    # FINAL PROPOSED DETECTOR
    #
    # IMPORTANT:
    #
    # NO KLEE TEST EVIDENCE
    # NO STATIC TEST FUSION
    #
    # Only refined learned detector.
    # ========================================================

    refined_probability = predict_probability(

        current_scaler,

        current_classifier,

        test_indices

    )


    refined_prediction = (

        refined_probability
        >=
        SEMANTIC_THRESHOLD

    ).astype(
        int
    )


    # ========================================================
    # ALL EVALUATION CONFIGURATIONS
    # ========================================================

    predictions = {


        "CodeBERT Semantic Head":

            semantic_prediction,


        "Static Pattern Only":

            static_test,


        "KLEE Symbolic Exec Only":

            klee_test,


        "IM-CED (Hybrid, No Retraining)":

            hybrid_prediction,


        "IM-CED (Proposed CE Feedback)":

            refined_prediction

    }


    for method in methods:


        result = calculate_metrics(

            y_test,

            predictions[
                method
            ]

        )


        for metric_name in [

            "acc",
            "prec",
            "rec",
            "f1"

        ]:


            metrics[
                method
            ][
                metric_name
            ].append(

                result[
                    metric_name
                ]

            )


# ============================================================
# 11. FINAL TABLE
# ============================================================

print(
    "\n"
    +
    "=" * 105
)


print(

    "[3/4] TABLE 2: CONTROLLED HELD-OUT TEST EVALUATION "
    f"(Mean ± Std Dev across {len(SEEDS)} Training Runs)"

)


print(

    f"      Evaluated on Fixed Untouched Held-Out "
    f"Test Set (N = {len(test_indices)} Programs)"

)


print(
    "=" * 105
)


print(

    f"{'Method / Configuration':<36} | "

    f"{'Accuracy (%)':<15} | "

    f"{'Precision (%)':<15} | "

    f"{'Recall (%)':<15} | "

    f"{'F1-Score (%)':<15}"

)


print(
    "-" * 105
)


summary = {}


for method in methods:


    accuracy_mean = np.mean(
        metrics[
            method
        ]["acc"]
    )


    accuracy_std = np.std(
        metrics[
            method
        ]["acc"]
    )


    precision_mean = np.mean(
        metrics[
            method
        ]["prec"]
    )


    precision_std = np.std(
        metrics[
            method
        ]["prec"]
    )


    recall_mean = np.mean(
        metrics[
            method
        ]["rec"]
    )


    recall_std = np.std(
        metrics[
            method
        ]["rec"]
    )


    f1_mean = np.mean(
        metrics[
            method
        ]["f1"]
    )


    f1_std = np.std(
        metrics[
            method
        ]["f1"]
    )


    print(

        f"{method:<36} | "

        f"{accuracy_mean:5.2f} ± {accuracy_std:4.2f} | "

        f"{precision_mean:5.2f} ± {precision_std:4.2f} | "

        f"{recall_mean:5.2f} ± {recall_std:4.2f} | "

        f"{f1_mean:5.2f} ± {f1_std:4.2f}"

    )


    summary[
        method
    ] = {

        "accuracy_mean":
            float(
                accuracy_mean
            ),

        "accuracy_std":
            float(
                accuracy_std
            ),

        "precision_mean":
            float(
                precision_mean
            ),

        "precision_std":
            float(
                precision_std
            ),

        "recall_mean":
            float(
                recall_mean
            ),

        "recall_std":
            float(
                recall_std
            ),

        "f1_mean":
            float(
                f1_mean
            ),

        "f1_std":
            float(
                f1_std
            )

    }


print(
    "=" * 105
)


# ============================================================
# 12. STATISTICAL TESTS
# ============================================================

f1_semantic = np.asarray(

    metrics[
        "CodeBERT Semantic Head"
    ]["f1"]

)


f1_proposed = np.asarray(

    metrics[
        "IM-CED (Proposed CE Feedback)"
    ]["f1"]

)


differences = (

    f1_proposed
    -
    f1_semantic

)


t_stat, p_t = stats.ttest_rel(

    f1_proposed,

    f1_semantic

)


try:

    w_stat, p_w = stats.wilcoxon(

        differences

    )

except ValueError:

    w_stat = np.nan
    p_w = np.nan


print(
    "\n"
    +
    "=" * 105
)


print(

    "[4/4] STATISTICAL TESTS "
    "(Proposed IM-CED vs. CodeBERT Baseline across 5 Seeds)"

)


print(
    "=" * 105
)


print(

    "  CodeBERT F1 Scores across Seeds: "
    f"{np.round(f1_semantic, 2).tolist()}"

)


print(

    "  IM-CED F1 Scores across Seeds:   "
    f"{np.round(f1_proposed, 2).tolist()}"

)


print(

    f"  Paired t-test: "
    f"t = {t_stat:.3f}, "
    f"p-value = {p_t:.4f}"

)


if not np.isnan(
    p_w
):


    print(

        f"  Wilcoxon Signed-Rank test: "
        f"W = {w_stat:.1f}, "
        f"p-value = {p_w:.4f}"

    )


else:


    print(

        "  Wilcoxon Signed-Rank test: "
        "not defined for these paired differences."

    )


print(
    "=" * 105
)


# ============================================================
# 13. SAVE FINAL RESULTS
# ============================================================

result_output = {


    "configuration": {

        "label_scope":
            "SV-COMP memory-safety properties only",

        "codebert_model":
            "microsoft/codebert-base",

        "codebert_frozen":
            True,

        "classification_head":
            "SGDClassifier logistic loss",

        "class_weight":
            "balanced",

        "seeds":
            SEEDS,

        "ce_rounds":
            CE_ROUNDS,

        "ce_budget_per_round":
            CE_BUDGET,

        "semantic_threshold":
            SEMANTIC_THRESHOLD,

        "klee_counterexample_criterion":
            ".err plus matching .ktest"

    },


    "dataset": {

        "total":
            int(
                len(dataset)
            ),

        "vulnerable":
            int(
                np.sum(
                    all_labels == 1
                )
            ),

        "safe":
            int(
                np.sum(
                    all_labels == 0
                )
            ),

        "train":
            int(
                len(
                    train_indices
                )
            ),

        "feedback":
            int(
                len(
                    feedback_indices
                )
            ),

        "test":
            int(
                len(
                    test_indices
                )
            )

    },


    "results":
        summary,


    "per_seed": {

        "codebert_f1":
            f1_semantic.tolist(),

        "imced_f1":
            f1_proposed.tolist(),

        "difference":
            differences.tolist()

    },


    "statistics": {

        "paired_t_test": {

            "t":
                float(
                    t_stat
                ),

            "p":
                float(
                    p_t
                )

        },


        "wilcoxon": {

            "W":

                None
                if np.isnan(
                    w_stat
                )
                else float(
                    w_stat
                ),

            "p":

                None
                if np.isnan(
                    p_w
                )
                else float(
                    p_w
                )

        }

    },


    "feedback_history":
        feedback_history

}


result_file = os.path.join(

    WINDOWS_BASE,

    "imced_FINAL_memorysafe_results.json"

)


with open(
    result_file,
    "w"
) as f:


    json.dump(

        result_output,

        f,

        indent=2

    )


print(
    "\nFINAL RESULTS SAVED TO:"
)


print(
    result_file
)


print(
    "\nFIXED SPLIT SAVED TO:"
)


print(
    split_file
)


print(
    "\n===================================================="
)


print(
    "FINAL EXPERIMENT COMPLETE"
)


print(
    "===================================================="
)